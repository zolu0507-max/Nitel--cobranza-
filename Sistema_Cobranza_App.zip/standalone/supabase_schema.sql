-- Ejecuta esto en Supabase: Panel izquierdo > SQL Editor > New query > pegar > Run

create table if not exists cobranza_kv (
  key text primary key,
  value text,
  updated_at timestamptz default now()
);

-- Habilita el acceso publico de lectura/escritura para esta tabla.
-- Es una app interna sencilla sin login; cualquiera con la URL de la app
-- puede leer y escribir estos datos. Si mas adelante quieres restringirlo
-- con usuarios y contrasena, se puede agregar autenticacion de Supabase.
alter table cobranza_kv enable row level security;

create policy "Lectura publica" on cobranza_kv
  for select using (true);

create policy "Escritura publica" on cobranza_kv
  for insert with check (true);

create policy "Actualizacion publica" on cobranza_kv
  for update using (true);
