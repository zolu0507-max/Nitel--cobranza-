# Sistema de Cobranza — App independiente

Esta es la misma app que probaste dentro de Claude, pero preparada para
vivir fuera de Claude, con una base de datos real y gratuita (Supabase).

Vas a necesitar unos 15-20 minutos y dos cuentas gratis (Supabase y Vercel).
No necesitas saber programar para seguir estos pasos, solo copiar y pegar.

## Paso 1: Crear la base de datos (Supabase)

1. Entra a https://supabase.com y crea una cuenta gratis.
2. Crea un proyecto nuevo (elige cualquier nombre y contraseña, guarda la
   contraseña en un lugar seguro).
3. Cuando el proyecto esté listo, ve a **SQL Editor** (menú izquierdo) →
   **New query**.
4. Abre el archivo `supabase_schema.sql` de esta carpeta, copia todo su
   contenido, pégalo ahí y dale a **Run**. Esto crea la tabla donde se
   guardan todos los pagos, descuentos, teléfonos, etc.
5. Ve a **Project Settings** (ícono de engranaje) → **API**.
   Ahí vas a ver dos datos que necesitas:
   - **Project URL** (algo como `https://xxxxx.supabase.co`)
   - **anon public key** (una clave larga de texto)

## Paso 2: Configurar el proyecto

1. Dentro de esta carpeta, crea una copia del archivo `.env.example` y
   renómbrala a `.env` (sin ".example").
2. Abre `.env` y reemplaza los valores con los que copiaste de Supabase:
   ```
   VITE_SUPABASE_URL=https://xxxxx.supabase.co
   VITE_SUPABASE_ANON_KEY=tu-clave-larga-aqui
   ```

## Paso 3: Probarlo en tu computadora (opcional pero recomendado)

Necesitas tener [Node.js](https://nodejs.org) instalado (descarga la
versión LTS). Luego, en una terminal, dentro de esta carpeta:

```
npm install
npm run dev
```

Esto te da un link (normalmente `http://localhost:5173`) que puedes abrir
en tu navegador para probar que todo funciona antes de publicarlo.

## Paso 4: Publicarlo en internet (Vercel)

1. Entra a https://vercel.com y crea una cuenta gratis (puedes usar tu
   cuenta de GitHub, Google, etc.).
2. La forma más simple sin usar GitHub:
   - En tu computadora, corre: `npm run build`
   - Esto crea una carpeta llamada `dist`.
   - En Vercel, busca la opción de subir manualmente ("Deploy" →
     arrastrar carpeta) y arrastra la carpeta `dist`.
3. Si prefieres la forma recomendada a largo plazo (más fácil de
   actualizar después):
   - Sube esta carpeta completa a un repositorio de GitHub.
   - En Vercel, elige "Import Project" y selecciona ese repositorio.
   - En **Environment Variables**, agrega `VITE_SUPABASE_URL` y
     `VITE_SUPABASE_ANON_KEY` con los mismos valores de tu `.env`.
   - Dale a **Deploy**.
4. Vercel te da un link tipo `tu-app.vercel.app` — ese es el link
   definitivo que puedes compartir con quien vaya a usar la app, y no
   depende de Claude para nada.

## ¿Se puede "descargar" como WhatsApp o TikTok?

Con lo que trae este proyecto (PWA), la app se puede **instalar en el
celular** y queda con su propio ícono en la pantalla de inicio, abre en
pantalla completa (sin la barra del navegador) y funciona igual que una
app normal — eso ya está listo, no necesitas hacer nada extra en el
código.

Lo que **no** incluye es publicarla en la App Store de Apple o en Google
Play. Eso es un proyecto aparte: requiere convertir el código a una app
nativa (por ejemplo con una herramienta llamada Capacitor), crear una
cuenta de desarrollador de Apple (99 USD/año) y de Google (25 USD pago
único), y pasar por su proceso de revisión, que puede tardar días. Si
más adelante quieres ese camino, puedo ayudarte a prepararlo, pero para
un sistema interno de cobranza de tu equipo, instalarla desde el
navegador (como se explica abajo) resuelve lo mismo sin esos costos ni
trámites.

**Cómo instalarla una vez que esté publicada (con su link de Vercel):**

En Android (Chrome):
1. Abre el link de tu app.
2. Aparece un aviso "Instalar app" o "Agregar a pantalla de inicio"
   automáticamente, o lo encuentras en el menú (los tres puntos) →
   **Instalar app**.
3. Queda el ícono de NITEL en tu pantalla de inicio, y abre en pantalla
   completa como cualquier otra app.

En iPhone (Safari):
1. Abre el link de tu app.
2. Toca el botón de compartir (el cuadrito con la flecha hacia arriba).
3. Elige **"Añadir a pantalla de inicio"**.
4. Queda el ícono de NITEL en tu pantalla de inicio.



- **Datos compartidos**: todos los que abran el link ven y editan la
  misma información en tiempo real (a través de Supabase), igual que
  antes.
- **Seguridad básica**: esta configuración no tiene usuario/contraseña
  para entrar a la app — cualquiera con el link puede ver y modificar los
  datos. Para un equipo pequeño de confianza esto suele ser suficiente,
  pero si más adelante quieres agregar un login, se puede hacer con la
  misma cuenta de Supabase (tiene autenticación integrada).
- **Costo**: tanto Supabase como Vercel tienen planes gratuitos que
  alcanzan de sobra para este uso (un negocio con ~600 clientes). No
  deberías pagar nada salvo que crezca mucho más.
- **Actualizaciones futuras**: si más adelante quieres que te agregue una
  función nueva, avísame, actualizo el código de `src/App.jsx` y subes
  de nuevo esa carpeta a Vercel (o simplemente vuelves a hacer
  `npm run build` y arrastrar `dist`).
