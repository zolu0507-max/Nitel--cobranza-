import { supabase } from "./supabaseClient";

// Misma forma que window.storage de los Artifacts de Claude (get/set con una
// clave de texto y un valor de texto), pero respaldado por una tabla real de
// Supabase (Postgres) para que los datos sean permanentes y compartidos entre
// todos los que usen la app, sin depender de Claude.

const TABLE = "cobranza_kv";

export const storage = {
  async get(key) {
    const { data, error } = await supabase
      .from(TABLE)
      .select("value")
      .eq("key", key)
      .maybeSingle();

    if (error) throw error;
    if (!data) return null;
    return { key, value: data.value };
  },

  async set(key, value) {
    const { error } = await supabase
      .from(TABLE)
      .upsert({ key, value, updated_at: new Date().toISOString() }, { onConflict: "key" });

    if (error) throw error;
    return { key, value };
  },
};
